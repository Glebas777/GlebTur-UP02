# SportShop — проект «СпортТовары»

Практическое занятие №6. Гибкие методы разработки (Scrum и Kanban).

## Структура

- docs/03_Product_Backlog.md — Product Backlog (12 User Story)
- docs/04_Sprint_Backlog.md — Sprint Backlog (5 историй, 6 часов)
- docs/05_Kanban_Board.md — Kanban-доска с WIP-лимитом = 2
- docs/06_Standup_Notes.md — Daily Standup (2 стендапа)
- docs/07_Retrospective.md — Ретроспектива спринта
- shop.py — реализация задач спринта
- actions.log — журнал действий (создаётся автоматически)
- orders.json — сохранённые заказы (создаётся автоматически)

## Запуск

    python shop.py
