# Заготовка ядра StudyOS

def enqueue_process(process):
    return True

def set_priority(pid, priority):
    return True

def allocate_memory(pid, size):
    return 0
