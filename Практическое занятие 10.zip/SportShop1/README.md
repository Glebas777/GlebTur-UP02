# СпортТовары – система управления магазином

## Описание
СпортТовары — консольное приложение на Python для управления магазином спортивных товаров.

## Требования
- Python 3.10+
- SQLite 3
- Git

## Установка
git clone https://github.com/Glebas777/GlebTur-UP02
cd SportShop1
pip install -r requirements.txt

## Запуск
python3 main.py

## Структура проекта
SportShop1/
├── src/
├── tests/
├── docs/
├── data/
├── main.py
├── build.py
└── README.md

## Тестирование
python3 -m unittest discover -s tests

## Авторы
- Тур Глеб Константинович, 3ИП-7-24.
