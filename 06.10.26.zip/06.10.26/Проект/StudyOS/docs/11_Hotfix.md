# Hotfix: cart-total

**Проблема:** функция cart_total возвращала сумму без учёта количества товаров.

**Решение:** добавлено умножение на quantity.

**Ветки:** hotfix/cart-total слита в main и develop.
