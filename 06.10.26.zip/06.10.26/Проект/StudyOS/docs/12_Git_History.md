* f53f1dd docs: обновлена история коммитов
* da96ba5 hotfix: исправлен cart_total (учёт количества)
*   e98fe47 main: перенос shop.py из develop
|\  
| * 6c20ac7 docs: описание PR для search-advanced
| * a5018ed US-2: реализован search_advanced
* | 52e6b0b develop: добавлен shop.py со всеми функциями
* | a53bc26 docs: история коммитов
* | 0d9b245 docs: описание hotfix cart-total
|/  
* b89c757 docs: описание разрешения конфликта
*   303eb1d Разрешён конфликт в total_sum
|\  
| * 9125060 US-2: total_sum v2 (с учётом количества)
* | cf63f88 US-2: total_sum v1 (без учёта количества)
|/  
* 0244358 US-1: добавлена функция get_low_stock
* b9449a8 docs: добавлена схема Git Flow
* eb56bfa Day 1: initial project structure for StudyOS
