# PR: feature/search-advanced → develop

**Что сделано:**
- Реализована функция search_advanced(products, query, category, min_price, max_price).
- Добавлены фильтры по категории и диапазону цен.

**Как проверить:**
1. Запустить python -m src.shop.
2. Вызвать search_advanced(products, "мяч", category="Игровые", min_price=100).

**Связанные задачи:** US-2

**Ревьюер:** Иванов И.И.
